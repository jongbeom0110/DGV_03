package DGV;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class movieSQL {
    // DB연동 3객체
    Connection con;             // 접속
    PreparedStatement pstmt;    // SQL문
    ResultSet rs;               // 결과

    // DB접속 메소드
    public void connect() {
        con = DBC.DBConnect();
    }

    // DB해제 메소드
    public void conClose() {
        try {
            con.close();    // 접속한 DB를 닫다(close)
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    TMember member = new TMember();
    Scanner sc = new Scanner(System.in);

    // 1. 회원가입 메소드
    public void TMember(TMember member) {
        try {
            // (1) sql문 작성 : 입력할 데이터 대신 '?' 작성
            String sql = "INSERT INTO TMEMBER VALUES(?, ?, ?, ?, ?)";

            pstmt = con.prepareStatement(sql);

            pstmt.setString(1, member.gettId());        //아이디
            pstmt.setString(2, member.gettPw());        //비밀번호
            pstmt.setString(3, member.gettName());      //이름
            pstmt.setString(4, member.gettBirth());     //생년월일
            pstmt.setString(5, member.gettPhone());     //핸드폰번호

            int result = pstmt.executeUpdate();

            // (5) 결과처리
            if (result > 0) {
                System.out.println("가입 성공!");
            } else {
                System.out.println("가입 실패!");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    // 2. 로그인 메소드
    public boolean memberLogin(String tId, String tPw) {
        boolean result = false;

        try {
            String sql = "SELECT * FROM TMEMBER WHERE  TID=? AND TPW=?";

            pstmt = con.prepareStatement(sql);

            pstmt.setString(1, tId);        //아이디
            pstmt.setString(2, tPw);        //비밀번호

            rs = pstmt.executeQuery();

            result = rs.next();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    //2-1. (1) 영화 상영 목록 메소드
    public void infoMovie() {
        try {
            // CGV 영화 페이지 URL
            String url = "http://www.cgv.co.kr/movies/?lt=1&ft=0";

            // Jsoup을 사용하여 웹 페이지의 HTML 가져오기
            Document doc = Jsoup.connect(url).get();

            // 영화 목록이 있는 HTML 요소 선택
            Elements movieElements = doc.select("div.sect-movie-chart ol li");

            // 각 영화 정보에 대해 반복
            int movieCount = movieElements.size();
            for (int i = 0; i < movieCount; i++) {
                Element movieElement = movieElements.get(i);

                // 영화 제목과 개봉일 추출
                String title = movieElement.select("strong.title").text();
                String releaseDate = movieElement.select("span.txt-info").text();

                // 마지막 요소인지 확인
                boolean isLastMovie = (i == movieCount - 1);

                // 마지막 요소가 아닌 경우에만 출력
                if (!isLastMovie) {
                    System.out.println("순위: " + (i + 1) + "위 | 영화 제목: " + title + "  |  개봉일: " + releaseDate);
                    System.out.println();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //2-1. (2) 영화 해당 날짜의 영화 번호 메소드
    public void choice(String mdate, String member) {
        Scanner sc = new Scanner(System.in);
        try {
            // 영화 정보를 가져오는 쿼리 실행
            String sql = "SELECT *  FROM MOVIE WHERE MDATE = '24/03/' || ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, mdate);

            // 쿼리 실행 및 결과 가져오기
            rs = pstmt.executeQuery();

            // 결과 출력을 위한 데이터 구조 초기화
            Map<Integer, String[]> movieDetails = new HashMap<>();
            boolean movies = false;
            while (rs.next()) {
                movies = true;
                int movieNum = rs.getInt("MNUM");
                String rName = rs.getString("MNAME");
                String rCinema = rs.getString("CINEMA");
                String rDate = rs.getString("MDATE");
                String rTime = rs.getString("MTIME");

                // 영화 정보를 맵에 저장
                movieDetails.put(movieNum, new String[]{rName, rCinema, rDate, rTime});

                // 영화 정보 출력
                System.out.println();
                System.out.println("영화 번호: " + movieNum + "     | 제목: " + rName + "     |상영관: " + rCinema);
                System.out.println("날짜: " + rDate + "    |상영 시간: " + rTime + "    | 가격: 15,000원");
            }
            // 선택한 날짜에 영화가 없을 경우 메시지 출력 후 종료
            if (!movies) {
                System.out.println("선택한 날짜에 상영 영화가 없습니다.");
                return;
            }
            System.out.println();
            if (movies) {
                // 사용자에게 영화 번호 선택을 요청
                System.out.print("영화 번호를 선택하세요>> ");
                int movieNum = sc.nextInt();

                // 선택한 영화 번호가 유효한지 확인 후 예약 정보 저장 메소드 호출
                if (movieDetails.containsKey(movieNum)) {
                    String[] details = movieDetails.get(movieNum);
                    saveReserv(movieNum, details[0], details[1], details[2], details[3], member);
                } else {
                    System.out.println("잘못된 영화 번호입니다.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //2-1. (3) 예약정보 저장
    public void saveReserv(int movieNum, String rName, String rCinema, String rDate, String rTime, String memberId) {
        try {
            // 현재 예약 테이블에서 최대 RNUM 조회
            String maxRnumSql = "SELECT MAX(RNUM) FROM RESERV";
            pstmt = con.prepareStatement(maxRnumSql);
            rs = pstmt.executeQuery();
            int maxRnum = 0;
            if (rs.next()) {
                maxRnum = rs.getInt(1);
            }

            // 새로운 예약의 RNUM은 최대 RNUM에 1을 더한 값입니다.
            int newRnum = maxRnum + 1;

            // 예약에 사용될 멤버 아이디 설정
            String tId = memberId;

            // 새로운 예약 정보를 데이터베이스에 저장하는 쿼리 작성
            String insertSql = "INSERT INTO RESERV (RNUM, TID, MNUM, RCHECK, MNAME, CINEMA, RDATE, RTIME) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            pstmt = con.prepareStatement(insertSql);

            // 예약 상태값 확인을 위한 RCHECK 값 생성
            int rcheck = checkNum();

            pstmt.setInt(1, newRnum);       // 예약 번호
            pstmt.setString(2, tId);        // 멤버 아이디
            pstmt.setInt(3, movieNum);      // 영화 번호
            pstmt.setInt(4, rcheck);        // 예매 고유 번호
            pstmt.setString(5, rName);      // 영화 제목
            pstmt.setString(6, rCinema);    // 상영관
            pstmt.setString(7, rDate);      // 상영 날짜
            pstmt.setString(8, rTime);      // 상영 시간

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                // 예약 성공 시 메시지 출력
                System.out.println();
                System.out.println("예약이 되었습니다. 예약번호: " + rcheck);
                System.out.println("2번 메뉴에서 예약번호[" + rcheck + "] 입력해 좌석을 선택해주세요");
                System.out.println();
            } else {
                // 예약 실패 시 메시지 출력
                System.out.println("예약 정보 저장에 실패하였습니다.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 2-1. (3) 예약번호 자동생성
    public int checkNum() {
        int rnum = 0;

        for (int i = 0; i < 6; i++) {
            rnum *= 10;
            rnum += (int) (Math.random() * 10);
        }
        return rnum;
    }

    //2-2. (1) 좌석 선택
    public void selectSeat() throws SQLException {
        try {
            // 사용자 ID 입력 받기
            System.out.print("사용자 ID를 입력해주세요: ");
            String tId = sc.next();

            // 예약 번호 입력 받기
            System.out.print("예약 번호(RCHECK)를 입력해주세요: ");
            int rcheck = sc.nextInt();

            //예약 번호 중복인지 확인
            if(seatReserved(rcheck)){
                System.out.println("이미 해당 예약 번호로 좌석이 예약되어 있습니다.");
                return;
            }

            // RESERV 테이블에서 예약 확인
            String sql = "SELECT * FROM RESERV WHERE TID=? AND RCHECK = ? ";
            pstmt = con.prepareStatement(sql);
            pstmt.setString(1, tId);
            pstmt.setInt(2, rcheck);
            rs = pstmt.executeQuery();

            // 입력된 예약 번호와 사용자 ID에 해당하는 예약이 없을 경우 메시지 출력 후 종료
            if (!rs.next()) {
                System.out.println("해당 예약 번호가 존재하지 않습니다.");
                return;
            }

            // 예약된 날짜(RDATE) 가져오기
            String rDate = rs.getString("RDATE");
            int movieNum = rs.getInt("MNUM");
            System.out.println("예약날짜 : " + rDate); // RDATE 값을 로그로 출력

            // 좌석 초기화
            if (checkReset(rDate, movieNum)) {
                resetSeats(rDate, movieNum);
            }

            // 좌석 배치도 표시
            displaySeats();

            // 좌석 선택 반복문
            while (true) {
                // 좌석 정보 입력 받기
                System.out.print("좌석 열(A, B, C, D, E)을 입력해주세요: ");
                String srow = sc.next();
                System.out.print("좌석 행(1, 2, 3, 4, 5)을 입력해주세요: ");
                int scol = sc.nextInt();

                // 해당 좌석의 예약 상태 확인
                sql = "SELECT STATUS FROM SEAT WHERE SROW = ? AND SCOL = ?";
                pstmt = con.prepareStatement(sql);
                pstmt.setString(1, srow);
                pstmt.setInt(2, scol);
                rs = pstmt.executeQuery();

                // 이미 예약된 좌석인 경우 메시지 출력 후 반복
                if (rs.next() && "RESERVED".equals(rs.getString("STATUS"))) {
                    System.out.println("이미 예약된 좌석입니다. 다른 좌석을 선택해주세요.");
                    continue;
                }

                // SEAT 테이블에 좌석 정보 저장 및 상태 업데이트
                sql = "INSERT INTO SEAT (RCHECK, MNUM, RDATE, SROW, SCOL, STATUS) VALUES (?, ?, ?, ?, ?, 'RESERVED')";
                pstmt = con.prepareStatement(sql);
                pstmt.setInt(1, rcheck);
                pstmt.setInt(2, movieNum);
                pstmt.setString(3, rDate);
                pstmt.setString(4, srow);
                pstmt.setInt(5, scol);
                pstmt.executeUpdate();

                Payment(tId);
                System.out.println("좌석이 예약되었습니다.");
                break;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //2-2. (2) 예약 번호 중복
    private boolean seatReserved(int rcheck) throws SQLException {
        String sql = "SELECT COUNT(*) FROM SEAT WHERE RCHECK = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, rcheck);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }

    //2-2. (3)  좌석 예약 유무
    private boolean checkReset(String rDate, int movieNum) throws SQLException {
        // 현재 날짜와 영화 번호에 대해 이미 예약된 좌석이 있는지 확인
        String sql = "SELECT COUNT(*) FROM SEAT WHERE RDATE = ? AND MNUM = ? AND STATUS = 'RESERVED'";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, rDate);
            pstmt.setInt(2, movieNum);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                // 이미 예약된 좌석이 없으면 true 반환 (초기화 필요)
                return rs.getInt(1) == 0;
            }
        }
        return false; // 기본적으로는 초기화하지 않음
    }

    //2-2. (4) 다른 날짜 다른 영화 좌석 초기화
    private void resetSeats(String rDate, int movieNum) throws SQLException {
        try {
            // 해당 날짜와 영화를 제외한 모든 좌석 초기화
            String sql = "UPDATE SEAT SET STATUS = 'EMPTY' WHERE (RDATE != ? OR MNUM != ?)";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, rDate);
                pstmt.setInt(2, movieNum);
                pstmt.executeUpdate();
            }

            // 선택된 날짜와 영화의 좌석만 초기화하지 않음
            sql = "UPDATE SEAT SET STATUS = 'RESERVED' WHERE RDATE = ? AND MNUM = ?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, rDate);
                pstmt.setInt(2, movieNum);
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    //2-2. (5) 좌석배치도
    private void displaySeats() throws SQLException {
        try {
            String sql = "SELECT * FROM SEAT";
            pstmt = con.prepareStatement(sql);
            rs = pstmt.executeQuery();

            char[][] seats = new char[5][5];
            //좌석 배열 초기화
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    seats[i][j] = '□';  // 초기값 설정
                }
            }
            // 데이터베이스에서 좌석 상태 읽어와서 배열에 반영
            while (rs.next()) {
                String srow = rs.getString("SROW");
                int scol = rs.getInt("SCOL");
                String status = rs.getString("STATUS");

                int row = srow.charAt(0) - 'A';  // 'A' -> 0, 'B' -> 1, ...
                int col = scol - 1;               // 1 -> 0, 2 -> 1, ...

                if ("RESERVED".equals(status)) {
                    seats[row][col] = '■';  // 예약된 좌석 표시
                }
            }
            // 좌석 배치도 출력
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    System.out.print(seats[i][j] + " ");
                }
                System.out.println();
            }
        } catch (SQLException e) {
        e.printStackTrace();
        throw e; // 예외를 다시 throw하여 상위 메서드로 전달
    }
}

    //2-2. (6) 결제하기
    public void Payment(String Id) throws SQLException {
        // 고객의 생년월일 조회
        String birthSql = "SELECT TBIRTH FROM TMEMBER WHERE TID = ?";
        pstmt = con.prepareStatement(birthSql);
        pstmt.setString(1, Id);
        rs = pstmt.executeQuery();

        if (rs.next()) {
            String birthStr = rs.getString("TBIRTH");
            int birthYear = Integer.parseInt(birthStr.substring(0, 4));

            // 미성년자인지 여부에 따라 요금 설정
            int price = (birthYear > 2005) ? 10000 : 15000;

            // 결제 정보 출력 및 핸드폰 결제 진행
            System.out.println();
            System.out.println("결제 요금: " + price + "원");
            System.out.println("결제를 진행 하겠습니다. 핸드폰 번호를 입력하세요:");
            String phoneNumber = sc.next();
            System.out.println("핸드폰 결제가 완료되었습니다.");
        } else {
            System.out.println("고객의 생년월일을 찾을 수 없습니다.");
        }
    }

    //2-3. 예매 조회
    public void ListCheck() throws SQLException {
        Scanner sc = new Scanner(System.in);
        try {
            // 사용자로부터 ID 및 예약 번호 입력 받기
            System.out.print("사용자 ID를 입력해주세요: ");
            String Id = sc.next();

            System.out.print("예약 번호를 입력해주세요: ");
            int rCheck = sc.nextInt();

            // 예약 정보와 좌석 정보 조회
            String sql = "SELECT R.RNUM, R.MNUM, R.MNAME, R.RDATE, R.RTIME, S.SROW, S.SCOL " +
                    "FROM RESERV R " +
                    "INNER JOIN SEAT S ON R.RCHECK = S.RCHECK " +
                    "WHERE R.RCHECK = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setInt(1, rCheck);
            rs = pstmt.executeQuery();

            // 조회 결과 출력
            if (rs.next()) {
                int movieNum = rs.getInt("MNUM");
                String movieName = rs.getString("MNAME");
                String date = rs.getString("RDATE");
                String time = rs.getString("RTIME");
                String seatRow = rs.getString("SROW");
                int seatCol = rs.getInt("SCOL");

                System.out.println();
                System.out.println("영화번호: " + movieNum);
                System.out.println("영화이름: " + movieName);
                System.out.println("날짜: " + date);
                System.out.println("시간: " + time);
                System.out.println("좌석: " + seatRow + seatCol);
            } else {
                System.out.println("해당하는 예약 정보가 없습니다.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    //2-4. 예매 취소
    public void cancel()throws SQLException {
        try {
            System.out.print("예약을 취소할 예약 번호를 입력하세요: ");
            int rcheck = sc.nextInt();

            // 해당 예약 번호로 예약된 좌석을 모두 취소
            String sql = "DELETE FROM SEAT WHERE RCHECK = ?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, rcheck);
                pstmt.executeUpdate();
            }

            // 예약 번호를 통해 RESERV 테이블에서 해당 예약 삭제
            sql = "DELETE FROM RESERV WHERE RCHECK = ?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, rcheck);
                pstmt.executeUpdate();
            }

            System.out.println("예약이 취소되었습니다.");
            System.out.println("결제된 금액은 3~5일 내로 취소됩니다.");
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    //2-5. 회원 수정 메소드
    public void memberModify(TMember member) {
        try {
            // (1) sql문 작성 : 입력할 데이터 대신 '?' 작성
            String sql = "UPDATE TMEMBER SET TPW=?, TNAME=?, TBIRTH=?, TPHONE=? WHERE TID=?";

            // (2) db 준비
            pstmt = con.prepareStatement(sql);

            // (3) sql문에서 '?' 데이터 처리
            // 수정할 컬럼들
            pstmt.setString(1, member.gettPw());        //비밀번호
            pstmt.setString(2, member.gettName());      //이름
            pstmt.setString(3, member.gettBirth());     //생년월일
            pstmt.setString(4, member.gettPhone());     //핸드폰 번호

            // 기준이 되는 컬럼 TID가 5번째 '?'
            pstmt.setString(5, member.gettId());

            // (4) 실행 : insert, update, delete(int result), select(ResultSet rs)
            int result = pstmt.executeUpdate();

            // (5) 결과처리
            if (result > 0) {
                System.out.println("수정 성공!");
            } else {
                System.out.println("수정 실패!");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //2-6. 회원 삭제 메소드
    public void memberDelete(String tId) {

        try {
            // (1) sql문 작성 : 입력할 데이터 대신 '?' 작성
            String sql = "DELETE FROM TMEMBER WHERE TID=?";

            // (2) db 준비
            pstmt = con.prepareStatement(sql);

            pstmt.setString(1, tId);

            int result = pstmt.executeUpdate();

            if(result>0){
                System.out.println("삭제 성공!");
            } else {
                System.out.println("삭제 실패!");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}








